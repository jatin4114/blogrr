from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.services.websocket_multiplexer import multiplexer
from app.services.chat_messages_service import store_message, get_undelivered_messages, mark_messages_as_delivered
from app.services.group_chat_service import store_group_message, get_group_messages
from app.schemas.chat_message_schema import ChatMessageSchema
from app.schemas.group_chat_schema import GroupMessageCreate
from app.db.models.users import User
from app.db.models.group_chats import GroupMember
from app.core.auth import get_current_user_ws
import logging
from datetime import datetime
import traceback
import json
import asyncio
from typing import Dict, Any, List, Optional

from app.services.time_service import time_service

router = APIRouter()
logger = logging.getLogger(__name__)

# Check if Celery is available
try:
    from app.tasks.chat_messages_tasks import deliver_message_task
    from app.tasks.group_chat_tasks import store_group_message_task
    from app.services.redis_service import RedisService
    redis_service = RedisService()
    CELERY_AVAILABLE = True
except ImportError:
    CELERY_AVAILABLE = False
    logger.warning("Celery is not available, tasks will be executed synchronously")

@router.websocket("/ws/multiplex")
async def multiplex_websocket_endpoint(websocket: WebSocket, db: Session = Depends(get_db)):
    """
    Unified WebSocket endpoint that handles both direct messages and group messages.
    
    Message format should be JSON with a 'type' field indicating the message type:
    - 'direct': Direct message to another user
    - 'group': Message to a group
    - 'join_group': Join a group channel
    - 'leave_group': Leave a group channel
    - 'heartbeat': Keep connection alive
    """
    # Log the connection attempt
    logger.info("Multiplex WebSocket connection attempt")
    
    try:
        # Get token from query params
        token = websocket.query_params.get('token')
        
        # Log headers and query params for debugging
        headers = {k: v for k, v in websocket.headers.items()}
        query_params = {k: v for k, v in websocket.query_params.items()}
        logger.info(f"WebSocket headers: {headers}")
        logger.info(f"WebSocket query params: {query_params}")
        
        # Authenticate user
        user = await get_current_user_ws(websocket, db, token)
        
        # Dev mode check
        dev_mode = websocket.query_params.get('dev_mode') == 'true'
        dev_user_id = websocket.query_params.get('dev_user_id')
        
        if not user and dev_mode and dev_user_id and dev_user_id.isdigit():
            # Development mode bypass
            logger.warning(f"DEVELOPMENT MODE: Bypassing authentication with dev_user_id={dev_user_id}")
            user = db.query(User).filter(User.id == int(dev_user_id)).first()
            
        if not user:
            # Authentication failed
            await websocket.accept()
            await websocket.send_json({"type": "error", "message": "Authentication failed"})
            await websocket.close(code=1008)
            logger.warning("WebSocket connection rejected due to failed authentication")
            return
        
        user_id = user.id
        logger.info(f"User {user_id} ({user.username}) authenticated for multiplexed WebSocket")
        
        # Accept connection
        await multiplexer.connect(websocket, user_id)
        
        # Send welcome message
        await websocket.send_json({
            "type": "system",
            "message": f"Connected as user {user.username} (ID: {user_id})"
        })
        
        # Send current server time for client synchronization
        server_time = time_service.get_current_timestamp()
        await websocket.send_json({
            "type": "time_sync",
            "server_time": server_time
        })
        logger.info(f"Sent time sync message with server time: {server_time}")
        
        # Setup heartbeat
        heartbeat_interval = 30  # seconds
        last_heartbeat = datetime.utcnow()
        
        # Send undelivered direct messages
        try:
            logger.info(f"Checking undelivered messages for user {user_id}")
            undelivered = get_undelivered_messages(db, user_id)
            
            if undelivered:
                await websocket.send_json({
                    "type": "system",
                    "message": f"You have {len(undelivered)} undelivered messages"
                })
                
                for msg in undelivered:
                    await websocket.send_json({
                        "type": "direct",
                        "sender_id": msg.sender_id,
                        "message": msg.message,
                        "timestamp": msg.timestamp.isoformat() if msg.timestamp else None
                    })
                
                # Mark as delivered
                mark_messages_as_delivered(db, user_id)
                
            # Sync with legacy manager
            await multiplexer.sync_with_simple_manager()
            
            # Initialize user's group membership from database
            group_memberships = db.query(GroupMember).filter(
                GroupMember.user_id == user_id
            ).all()
            
            for membership in group_memberships:
                multiplexer.join_group(user_id, membership.group_id)
                
            logger.info(f"User {user_id} initialized with {len(group_memberships)} group memberships")
            
        except Exception as e:
            logger.error(f"Error during initialization: {str(e)}")
            logger.error(traceback.format_exc())
            await websocket.send_json({"type": "error", "message": "Initialization error"})
                
        # Main message processing loop
        try:
            while True:
                # Check if we need to send a heartbeat ping
                if (datetime.utcnow() - last_heartbeat).total_seconds() > heartbeat_interval:
                    await websocket.send_json({"type": "heartbeat", "timestamp": datetime.utcnow().isoformat()})
                    last_heartbeat = datetime.utcnow()
                
                # Try to receive message with a timeout
                try:
                    # Set a timeout for receive_json to allow heartbeat checks
                    data = await asyncio.wait_for(
                        websocket.receive_json(), 
                        timeout=heartbeat_interval
                    )
                except asyncio.TimeoutError:
                    # Timeout occurred, loop will continue and send heartbeat
                    continue
                
                # Process the message based on its type
                if not isinstance(data, dict) or "type" not in data:
                    await websocket.send_json({"type": "error", "message": "Invalid message format, missing 'type'"})
                    continue
                
                message_type = data.get("type")
                
                # DIRECT MESSAGE
                if message_type == "direct":
                    await handle_direct_message(websocket, db, user, data)
                
                # GROUP MESSAGE
                elif message_type == "group":
                    await handle_group_message(websocket, db, user, data)
                
                # JOIN GROUP
                elif message_type == "join_group":
                    group_id = data.get("group_id")
                    if not group_id:
                        await websocket.send_json({"type": "error", "message": "Missing group_id"})
                        continue
                    
                    # Verify user is a member of this group
                    is_member = db.query(GroupMember).filter(
                        GroupMember.group_id == group_id,
                        GroupMember.user_id == user_id
                    ).first()
                    
                    if is_member:
                        multiplexer.join_group(user_id, group_id)
                        await websocket.send_json({
                            "type": "system", 
                            "message": f"Joined group channel {group_id}"
                        })
                    else:
                        await websocket.send_json({
                            "type": "error", 
                            "message": f"You are not a member of group {group_id}"
                        })
                
                # LEAVE GROUP
                elif message_type == "leave_group":
                    group_id = data.get("group_id")
                    if not group_id:
                        await websocket.send_json({"type": "error", "message": "Missing group_id"})
                        continue
                    
                    multiplexer.leave_group(user_id, group_id)
                    await websocket.send_json({
                        "type": "system", 
                        "message": f"Left group channel {group_id}"
                    })
                
                # HEARTBEAT
                elif message_type == "heartbeat":
                    last_heartbeat = datetime.utcnow()
                    await websocket.send_json({
                        "type": "heartbeat", 
                        "timestamp": last_heartbeat.isoformat()
                    })
                
                # Handle typing events
                elif message_type == "typing_start":
                    await multiplexer.broadcast_typing_event(data["chat_id"], user.id, "typing_start")
                elif message_type == "typing_stop":
                    await multiplexer.broadcast_typing_event(data["chat_id"], user.id, "typing_stop")
                
                # UNKNOWN TYPE
                else:
                    await websocket.send_json({
                        "type": "error", 
                        "message": f"Unknown message type: {message_type}"
                    })
                    
        except WebSocketDisconnect:
            logger.info(f"WebSocket disconnected for user {user_id}")
            multiplexer.disconnect(user_id)
            
    except Exception as e:
        logger.error(f"Error in multiplexed WebSocket: {str(e)}")
        logger.error(traceback.format_exc())
        try:
            await websocket.accept()
            await websocket.send_json({"error": f"Server error: {str(e)}"})
            await websocket.close(code=1011)
        except:
            pass

async def handle_direct_message(websocket: WebSocket, db: Session, user: User, data: Dict[str, Any]):
    """Process direct messages within the multiplexed endpoint"""
    user_id = user.id
    
    if "receiver_id" not in data:
        await websocket.send_json({"type": "error", "message": "Missing receiver_id"})
        return
        
    if "message" not in data:
        await websocket.send_json({"type": "error", "message": "Missing message content"})
        return
    
    # Verify receiver exists
    receiver = db.query(User).filter(User.id == data["receiver_id"]).first()
    if not receiver:
        await websocket.send_json({
            "type": "error",
            "message": f"Receiver with ID {data['receiver_id']} does not exist"
        })
        return
    
    try:
        # Add timestamp if not provided or normalize the provided timestamp
        if "timestamp" in data and data["timestamp"]:
            try:
                # Normalize the timestamp using time_service
                current_time = time_service.parse_timestamp(data["timestamp"])
                logger.info(f"Client provided timestamp: {data['timestamp']}")
                
                # Convert to a properly formatted ISO string in UTC
                current_time_iso = time_service.format_timestamp(current_time)
                logger.info(f"Normalized timestamp: {current_time_iso}")
            except Exception as e:
                logger.warning(f"Error parsing client timestamp: {str(e)}")
                current_time = datetime.now(datetime.timezone.utc)
                current_time_iso = current_time.isoformat()
        else:
            # Get current time in UTC with timezone info
            current_time = datetime.now(datetime.timezone.utc)
            current_time_iso = current_time.isoformat()
            logger.info(f"Using server timestamp: {current_time_iso}")
        
        # Create message schema with the normalized timestamp
        message_schema = ChatMessageSchema(
            sender_id=user_id,
            receiver_id=data["receiver_id"],
            message=data["message"],
            timestamp=current_time,
            delivered=False
        )
        
        # Store message
        message_dict = message_schema.dict(exclude_none=True)
        stored_message = None
        message_id = None
        
        if CELERY_AVAILABLE:
            try:
                task_result = deliver_message_task.delay(message_dict)
                logger.info(f"Message queued with Celery: {task_result.id}")
                message_id = task_result.id
            except Exception as celery_error:
                logger.error(f"Celery task failed: {str(celery_error)}")
                logger.warning("Falling back to direct DB write")
                stored_message = store_message(db, message_schema)
                message_id = stored_message.id if stored_message else None
        else:
            stored_message = store_message(db, message_schema)
            message_id = stored_message.id if stored_message else None
        
        # Send confirmation to sender with the normalized timestamp
        await websocket.send_json({
            "type": "confirmation",
            "message_type": "direct",
            "message_id": message_id,
            "receiver_id": data["receiver_id"],
            "timestamp": current_time_iso
        })
        
        # Try to deliver to receiver with the normalized timestamp
        if multiplexer.is_connected(data["receiver_id"]):
            success = await multiplexer.send_direct_message(data["receiver_id"], {
                "type": "direct",
                "sender_id": user_id,
                "message": data["message"],
                "timestamp": current_time_iso
            })
            
            if success and stored_message:
                stored_message.delivered = True
                db.commit()
                logger.info(f"Message {stored_message.id} marked as delivered immediately")
            
    except Exception as e:
        logger.error(f"Error processing direct message: {str(e)}")
        await websocket.send_json({
            "type": "error",
            "message": f"Failed to process message: {str(e)}"
        })

async def handle_group_message(websocket: WebSocket, db: Session, user: User, data: Dict[str, Any]):
    """Process group messages within the multiplexed endpoint"""
    user_id = user.id
    
    if "group_id" not in data:
        await websocket.send_json({"type": "error", "message": "Missing group_id"})
        return
        
    if "message" not in data:
        await websocket.send_json({"type": "error", "message": "Missing message content"})
        return
    
    group_id = data["group_id"]
    
    # Verify user is a member of this group
    is_member = db.query(GroupMember).filter(
        GroupMember.group_id == group_id,
        GroupMember.user_id == user_id
    ).first()
    
    if not is_member:
        await websocket.send_json({
            "type": "error", 
            "message": "You are not a member of this group"
        })
        return
    
    try:
        # Join group channel if not already
        if not multiplexer.is_in_group(user_id, group_id):
            multiplexer.join_group(user_id, group_id)
        
        # Create message schema
        message_schema = GroupMessageCreate(
            group_id=group_id,
            message=data["message"]
        )
        
        # Send to Celery or direct DB
        if CELERY_AVAILABLE:
            task_data = {
                "group_id": group_id,
                "sender_id": user_id,
                "message": data["message"]
            }
            task = store_group_message_task.delay(task_data)
            message_id = task.id
            
            # Publish to Redis for real-time delivery
            redis_message = {
                "type": "group_message",
                "message_id": message_id,
                "group_id": group_id, 
                "sender_id": user_id,
                "message": data["message"],
                "timestamp": datetime.utcnow().isoformat()
            }
            redis_service.publish_message(f"group:{group_id}", redis_message)
            
        else:
            # Direct DB storage without Celery
            stored_message = store_group_message(db, message_schema, user_id)
            message_id = stored_message.id
            
            # Broadcast directly without Redis
            await multiplexer.broadcast_to_group(
                group_id,
                {
                    "type": "group",
                    "group_id": group_id,
                    "sender_id": user_id,
                    "message": data["message"],
                    "timestamp": datetime.utcnow().isoformat(),
                    "message_id": str(message_id)
                },
                exclude_user_id=user_id  # Don't send to self
            )
        
        # Send confirmation to sender
        await websocket.send_json({
            "type": "confirmation",
            "message_type": "group",
            "message_id": message_id,
            "group_id": group_id,
            "timestamp": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Error processing group message: {str(e)}")
        await websocket.send_json({
            "type": "error",
            "message": f"Failed to process group message: {str(e)}"
        })
