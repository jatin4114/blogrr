import json
import logging
import asyncio
from fastapi import WebSocket
from typing import Dict, List, Set, Any, Optional
from app.services.websocket_service import manager as simple_manager
from app.services.redis_service import redis_service
# Use time_service instead of datetime directly
from app.services.time_service import time_service

logger = logging.getLogger(__name__)

class MultiplexedConnectionManager:
    """
    Enhanced WebSocket manager that supports multiplexed connections
    where a single WebSocket connection can handle multiple channels
    """
    
    def __init__(self):
        # Store active connections with user_id as the key
        self.active_connections: Dict[int, WebSocket] = {}
        # Store group memberships: {user_id: {group_id1, group_id2, ...}}
        self.user_groups: Dict[int, Set[int]] = {}
        # Keep track of connection status
        self.connection_status: Dict[int, bool] = {}
        # Track already synced connections
        self.synced_connections: Set[int] = set()
        
    async def connect(self, websocket: WebSocket, user_id: int):
        """
        Connect a user's WebSocket and initialize their channels
        """
        await websocket.accept()
        self.active_connections[user_id] = websocket
        self.connection_status[user_id] = True
        
        # Initialize group membership set if not exists
        if user_id not in self.user_groups:
            self.user_groups[user_id] = set()
            
        logger.info(f"User {user_id} connected via multiplexed WebSocket")
        return True
        
    def disconnect(self, user_id: int):
        """
        Disconnect a user's WebSocket and clean up resources
        """
        if user_id in self.active_connections:
            del self.active_connections[user_id]
        
        if user_id in self.user_groups:
            del self.user_groups[user_id]
            
        if user_id in self.connection_status:
            del self.connection_status[user_id]
        
        # Clean up synced connections tracking
        if user_id in self.synced_connections:
            self.synced_connections.remove(user_id)
            
        logger.info(f"User {user_id} disconnected from multiplexed WebSocket")
        
    def join_group(self, user_id: int, group_id: int):
        """
        Add user to a group channel
        """
        if user_id not in self.user_groups:
            self.user_groups[user_id] = set()
            
        self.user_groups[user_id].add(group_id)
        logger.info(f"User {user_id} joined group channel {group_id}")
        
    def leave_group(self, user_id: int, group_id: int):
        """
        Remove user from a group channel
        """
        if user_id in self.user_groups and group_id in self.user_groups[user_id]:
            self.user_groups[user_id].remove(group_id)
            logger.info(f"User {user_id} left group channel {group_id}")
            
    def is_in_group(self, user_id: int, group_id: int) -> bool:
        """
        Check if user is in a specific group channel
        """
        return user_id in self.user_groups and group_id in self.user_groups[user_id]
    
    def is_connected(self, user_id: int) -> bool:
        """
        Check if a user is connected
        """
        return user_id in self.active_connections
    
    async def broadcast_to_group(self, group_id: int, message: Dict[str, Any], exclude_user_id: Optional[int] = None):
        """
        Send message to all members of a group except the sender
        """
        sent_count = 0
        for user_id, groups in self.user_groups.items():
            if user_id != exclude_user_id and group_id in groups and user_id in self.active_connections:
                try:
                    await self.active_connections[user_id].send_json(message)
                    sent_count += 1
                except Exception as e:
                    logger.error(f"Error sending to user {user_id} in group {group_id}: {str(e)}")
                    # Don't disconnect here, let the heartbeat mechanism handle it
        
        logger.info(f"Broadcast message to {sent_count} users in group {group_id}")
        return sent_count
        
    async def send_direct_message(self, user_id: int, message: Dict[str, Any]) -> bool:
        """
        Send a direct message to a specific user
        Returns True if message was sent successfully
        """
        if user_id in self.active_connections:
            try:
                await self.active_connections[user_id].send_json(message)
                return True
            except Exception as e:
                logger.error(f"Error sending direct message to user {user_id}: {str(e)}")
                # Don't disconnect on errors, let the heartbeat mechanism handle it
                return False
        return False
    
    async def sync_with_simple_manager(self):
        """
        Keep the simple connection manager in sync with this multiplexed one
        for backward compatibility
        """
        for user_id, websocket in self.active_connections.items():
            # Skip if already synced to avoid double-accept error
            if user_id in self.synced_connections:
                continue
                
            if not simple_manager.is_connected(user_id):
                # We need to create a new websocket for the simple manager,
                # can't reuse the already accepted websocket
                try:
                    simple_manager.active_connections[str(user_id)] = websocket
                    logger.info(f"Synced user {user_id} with simple manager")
                    self.synced_connections.add(user_id)
                except Exception as e:
                    logger.error(f"Error syncing with simple manager: {str(e)}")
                
        # Remove connections from simple manager that are no longer in multiplexed
        for user_id_str in list(simple_manager.active_connections.keys()):
            try:
                user_id = int(user_id_str)
                if user_id not in self.active_connections:
                    simple_manager.disconnect(user_id)
            except ValueError:
                # Skip non-integer keys (like group connections)
                pass

    async def broadcast_typing_event(self, chat_id: int, user_id: int, event: str):
        """
        Broadcast typing events (start/stop) to all members of a chat.
        """
        message = {
            "type": event,
            "chat_id": chat_id,
            "user_id": user_id,
            # Use time_service for consistent timestamp format
            "timestamp": time_service.get_current_timestamp()
        }
        await self.broadcast_to_group(chat_id, message)

# Global instance for use throughout the application
multiplexer = MultiplexedConnectionManager()
